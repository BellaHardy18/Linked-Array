/**
 * TODO: Add your file header
 * Name: Bella Hardy
 * ID: A16369822
 * Email: Ihardy@ucsd.edu
 * File description: 
 * this file holds the MyArrayList class
 * that helps to maniplualte and arraylist with 
 * several different methods one of which I have implemented
 * to reverse a secion of an array list. 
 */

/**
 * this class sets up an array list and 
 * holds several methods to help access that
 * array list such as get and size as well as the 
 * constructor. There is another method called reverseregion
 * in which I have implemented a way to flip a 
 * portion of the array list so that the end of a section is
 * now the beginning and vise versa as the beginning is now
 * the end.
 * 
 */
public class MyArrayList<E> implements MyReverseList<E> {
    static final int DEFAULT_CAPACITY = 5;
    
    Object[] data;
    int size;

    //IMPORTANT: DO NOT MODIFY THIS CONSTRUCTOR!
    //IMPORTANT: DO NOT ADD ANY MORE CONSTRUCTORS!

    /**
     * Constructor to create an array list with the given array's elements
     * @param arr - array of elements to be used to construct the ArrayList
     */
    public MyArrayList(E[] arr) {
        if (arr == null) {
            this.data = new Object[DEFAULT_CAPACITY];
        } else {
            this.data = arr.clone();
            this.size = arr.length;
        }
    }

    /**
	 * this method takes 
     * in two parameters,
     *  the beginning
     * index and the ending index of 
     * which we would like to flip. 
     * This method takes into 
     * account certian indexing 
     * out of bounds issues as well. 
     * @param fromIndex
     * @param toIndex
     * @return none
	 */
    public void reverseRegion(int fromIndex, int toIndex){
        //checks for an index that is not within the
        //bounds of the list
        if(fromIndex > size() || fromIndex < 0 ||
        toIndex > size() || toIndex < 0){
            throw new IndexOutOfBoundsException();
        }
        //if the indexes are the same or if from
        //is greater than,just keep the list the same
        if(fromIndex >= toIndex){
            data = data;
        }
        else{
            //variable to make size of the array
            int sizeReverseRegion = (toIndex - fromIndex) + 1;
            //updater to sort through array
            int updater = 0;
            //new array created
            Object[] holderArray = 
            new Object[sizeReverseRegion];
            //for loop to gather all the data from the 
            //original array and put in new one
            for(int i = fromIndex; i <= toIndex; i++){
                holderArray[updater] = data[i];
                updater++;
            }
            //put the new array in reverse order 
            // back into the original array
            for(int j = fromIndex; j<= toIndex; j++){
                updater--;
                data[j] = holderArray[updater];
            }
        }
        
       /**
        * TODO: Add your solution here
        */
    }

    @Override
    /**
     * A method that returns the number of valid elements
     * in the ArrayList 
     * @return - number of valid elements in the arraylist
     */
    public int size() {
        return this.size;
    }

    @Override
    /**
     * A method that returns an Element at the specified index
     * @param index - the index of the return Element
     * @return Element at specified index
     */
    @SuppressWarnings("unchecked")
    public E get(int index) {
        return (E) data[index];
    }
}
