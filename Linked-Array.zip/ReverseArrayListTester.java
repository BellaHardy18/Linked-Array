/**
 * Tests to check the implementation of reverseRegion method in MyArrayList.java
*/

//other import statements

import org.junit.*;

import static org.junit.Assert.*;

//IMPORTANT: DO NOT MODIFY THE TEST HEADERS!
/**
 * This class contains various test cases to test the reverseRegion method
 */
public class ReverseArrayListTester {

    Integer[] arrInts = { 1, 2, 3, 4, 5, 6, 7};
    String[] stringArray = {"appa","bird","isabella", "alex", "bella", "bunny"};
    String[] oneItem = {"hello"};
         

    private MyArrayList 
    intArrayList, stringArrayList, oneItemArrayList;

    private MyLinkedList stringLinked, integerLinked, oneItemLinkedList;


    /**
     * Run before every test
     */
    @Before
    public void setUp(){
        intArrayList = new MyArrayList<Integer>(arrInts);
        stringArrayList = new MyArrayList<String>(stringArray);
        stringLinked = new MyLinkedList<String>(stringArray);
        integerLinked = new MyLinkedList<Integer>(arrInts);
        oneItemArrayList = new MyArrayList<>(oneItem);
        oneItemLinkedList = new MyLinkedList<>(oneItem);
    }


    /**
     * Tests reverseRegion method when either fromIndex or toIndex
     * or both are out of bounds.
     */
    @Test (expected = 
    IndexOutOfBoundsException.class)
    public void testReverseIndexOutOfBounds(){
        stringArrayList.reverseRegion(90,80);
        intArrayList.reverseRegion(90, 80);
        integerLinked.reverseRegion(90, 80);
        stringLinked.reverseRegion(90, 80);
    }

    /**
     * Tests reverseRegion method when
     * fromIndex > toIndex
     */
    @Test
    public void testReverseFromIndexGreater(){
        stringArrayList.reverseRegion(2,1);
        intArrayList.reverseRegion(2,1);
        integerLinked.reverseRegion(2, 1);
        stringLinked.reverseRegion(2, 1);


        assertEquals("cheking index data", "bunny", stringArrayList.get(5));
        assertEquals("cheking index data", "bella", stringArrayList.get(4));
        assertEquals("cheking index data", "alex", stringArrayList.get(3));
        assertEquals("cheking index data", "isabella", stringArrayList.get(2));
        assertEquals("cheking index data", "bird", stringArrayList.get(1));
        assertEquals("cheking index data", "appa", stringArrayList.get(0));

        assertEquals("cheking index data", 7, intArrayList.get(6));
        assertEquals("cheking index data", 6, intArrayList.get(5));
        assertEquals("cheking index data", 5, intArrayList.get(4));
        assertEquals("cheking index data", 4, intArrayList.get(3));
        assertEquals("cheking index data", 3, intArrayList.get(2));
        assertEquals("cheking index data", 2, intArrayList.get(1));
        assertEquals("cheking index data", 1, intArrayList.get(0));
        
        assertEquals("cheking index data", "bunny", stringLinked.get(5));
        assertEquals("cheking index data", "bella", stringLinked.get(4));
        assertEquals("cheking index data", "alex", stringLinked.get(3));
        assertEquals("cheking index data", "isabella", stringLinked.get(2));
        assertEquals("cheking index data", "bird", stringLinked.get(1));
        assertEquals("cheking index data", "appa", stringLinked.get(0));

        assertEquals("cheking index data", 7, integerLinked.get(6));
        assertEquals("cheking index data", 6, integerLinked.get(5));
        assertEquals("cheking index data", 5, integerLinked.get(4));
        assertEquals("cheking index data", 4, integerLinked.get(3));
        assertEquals("cheking index data", 3, integerLinked.get(2));
        assertEquals("cheking index data", 2, integerLinked.get(1));
        assertEquals("cheking index data", 1, integerLinked.get(0));

    }

    /**
     * Tests reverseRegion method when
     * fromIndex and toIndex are within bounds
    */
    @Test
    public void testReverseIndexWithinBounds(){
        stringArrayList.reverseRegion(2,4);
        intArrayList.reverseRegion(2,4);
        integerLinked.reverseRegion(2, 4);
        stringLinked.reverseRegion(2, 4);     

        assertEquals("chekcing linked", "bella",stringLinked.get(2));
        assertEquals("chekcing linked", "alex", stringLinked.get(3));
        assertEquals("chekcing linked", "isabella",stringLinked.get(4));

        assertEquals("chekcing linked", 5,integerLinked.get(2));
        assertEquals("chekcing linked", 4, integerLinked.get(3));
        assertEquals("chekcing linked", 3,integerLinked.get(4));


        assertEquals("cheking index data", "bella", stringArrayList.get(2));
        assertEquals("cheking index data", "alex", stringArrayList.get(3));
        assertEquals("cheking index data", "isabella", stringArrayList.get(4));

        assertEquals("cheking index data", 5, intArrayList.get(2));
        assertEquals("cheking index data",4, intArrayList.get(3));
        assertEquals("cheking index data", 3, intArrayList.get(4));
    }

    /**
     * this test not only flips a set ammount of indexes
     * it flips the entire arraylist including the ending 
     * indexes.
    */
    @Test
    public void testReverseCustom(){
        stringArrayList.reverseRegion(0,5);
        intArrayList.reverseRegion(0,6);
        integerLinked.reverseRegion(0, 6);
        stringLinked.reverseRegion(0, 5);
        assertEquals("cheking index data", "bunny", stringArrayList.get(0));
        assertEquals("cheking index data", "bella", stringArrayList.get(1));
        assertEquals("cheking index data", "alex", stringArrayList.get(2));
        assertEquals("cheking index data", "isabella", stringArrayList.get(3));
        assertEquals("cheking index data", "bird", stringArrayList.get(4));
        assertEquals("cheking index data", "appa", stringArrayList.get(5));

        assertEquals("cheking index data", "bunny", stringLinked.get(0));
        assertEquals("cheking index data", "bella", stringLinked.get(1));
        assertEquals("cheking index data", "alex", stringLinked.get(2));
        assertEquals("cheking index data", "isabella", stringLinked.get(3));
        assertEquals("cheking index data", "bird", stringLinked.get(4));
        assertEquals("cheking index data", "appa", stringLinked.get(5));

        assertEquals("cheking index data", 7, intArrayList.get(0));
        assertEquals("cheking index data", 6, intArrayList.get(1));
        assertEquals("cheking index data", 5, intArrayList.get(2));
        assertEquals("cheking index data", 4, intArrayList.get(3));
        assertEquals("cheking index data", 3, intArrayList.get(4));
        assertEquals("cheking index data", 2, intArrayList.get(5));
        assertEquals("cheking index data", 1, intArrayList.get(6));


        assertEquals("cheking index data", 7, integerLinked.get(0));
        assertEquals("cheking index data", 6, integerLinked.get(1));
        assertEquals("cheking index data", 5, integerLinked.get(2));
        assertEquals("cheking index data", 4, integerLinked.get(3));
        assertEquals("cheking index data", 3, integerLinked.get(4));
        assertEquals("cheking index data", 2, integerLinked.get(5));
        assertEquals("cheking index data", 1, integerLinked.get(6));

    }

    /**
    * reverses one item in the list 
    when the entire list is one item
    */
    @Test
    public void testOneItem(){ 
        stringArrayList.reverseRegion(0,0);
        intArrayList.reverseRegion(0,0);
        assertEquals("cheking index data", "hello", oneItemArrayList.get(0));
        assertEquals("cheking index data", "hello", oneItemLinkedList.get(0));

    }


}
